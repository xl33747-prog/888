# 基金AI（个人版）网页版 v0.3

## 1) 安装
```bash
cd fund_ai_web_v0_3
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## 2) 运行
```bash
streamlit run app.py
```

打开浏览器里显示的地址（通常是 http://localhost:8501）

## 3) 手机访问（可选）
同一 Wi‑Fi 下，把 Streamlit 绑定到 0.0.0.0：
```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```
然后手机浏览器打开：
http://<你的电脑局域网IP>:8501

## 4) 说明
- “支付宝所有基金”没有官方公开接口；本工具使用东财公开的全市场基金清单，和支付宝展示高度重合。
- 盘中“估值”来源于公开估值接口，可能延迟或对个别基金不可用。
- 风险评分仅供个人参考，不构成投资建议。
