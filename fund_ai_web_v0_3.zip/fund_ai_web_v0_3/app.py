# Fund AI Web v0.3 (personal use)
# Run: streamlit run app.py
import re
import time
import sqlite3
from typing import Optional, Dict, Any, List, Tuple

import requests
import pandas as pd
import streamlit as st

UA = {"User-Agent": "Mozilla/5.0"}

FUND_LIST_JS = "http://fund.eastmoney.com/js/fundcode_search.js"
FUND_GZ = "https://fundgz.1234567.com.cn/js/{code}.js"
FUND_LSJZ = "https://fundf10.eastmoney.com/F10DataApi.aspx?type=lsjz&code={code}&page={page}&per={per}"

DB_PATH = "db.sqlite"


def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS watchlist(code TEXT PRIMARY KEY)")
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS fund_universe(
            code TEXT PRIMARY KEY,
            name TEXT,
            pinyin TEXT,
            ftype TEXT,
            updated_at INTEGER
        )
        """
    )
    conn.commit()
    return conn


def _parse_fund_list_js(text: str):
    m = re.search(r"var\s+r\s*=\s*(\[\[.*\]\]);", text, re.S)
    if not m:
        raise RuntimeError("fund list parse failed")
    arr_text = m.group(1)
    data = eval(arr_text, {"__builtins__": {}})
    return data


@st.cache_data(ttl=24 * 3600, show_spinner=False)
def refresh_universe(force: bool = False) -> int:
    conn = db()
    cur = conn.cursor()
    row = cur.execute("SELECT COUNT(*) FROM fund_universe").fetchone()
    count = int(row[0]) if row else 0
    row2 = cur.execute("SELECT MIN(updated_at) FROM fund_universe").fetchone()
    updated_at = int(row2[0]) if row2 and row2[0] is not None else 0
    now = int(time.time())
    if (not force) and count > 0 and (now - updated_at) < 7 * 24 * 3600:
        return count

    r = requests.get(FUND_LIST_JS, headers=UA, timeout=20)
    r.raise_for_status()
    data = _parse_fund_list_js(r.text)

    cur.execute("DELETE FROM fund_universe")
    for row in data:
        code = str(row[0])
        pinyin = str(row[1])
        name = str(row[2])
        ftype = str(row[3]) if len(row) > 3 else ""
        cur.execute(
            "INSERT OR REPLACE INTO fund_universe(code,name,pinyin,ftype,updated_at) VALUES(?,?,?,?,?)",
            (code, name, pinyin, ftype, now),
        )
    conn.commit()
    return len(data)


def search_universe(q: str = "", share_class: str = "A", limit: int = 50) -> List[Dict[str, Any]]:
    conn = db()
    cur = conn.cursor()
    q = (q or "").strip()
    share_class = (share_class or "A").lower()

    where = []
    params: List[Any] = []

    if q:
        where.append("(code LIKE ? OR name LIKE ? OR pinyin LIKE ?)")
        like = f"%{q}%"
        params.extend([like, like, like])

    if share_class == "a":
        where.append("(name LIKE '%A' OR name LIKE '%A类' OR name LIKE '%A份额')")
    elif share_class == "c":
        where.append("(name LIKE '%C' OR name LIKE '%C类' OR name LIKE '%C份额')")

    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    sql = f"SELECT code,name,ftype FROM fund_universe {wsql} ORDER BY code LIMIT ?"
    params.append(limit)
    rows = cur.execute(sql, params).fetchall()
    return [{"code": r[0], "name": r[1], "type": r[2]} for r in rows]


def _parse_jsonp(text: str) -> Optional[Dict[str, Any]]:
    m = re.search(r"\((\{.*\})\)", text)
    if not m:
        return None
    import json
    return json.loads(m.group(1))


@st.cache_data(ttl=20, show_spinner=False)
def get_fund_gz(code: str) -> Optional[Dict[str, Any]]:
    code = code.strip()
    try:
        r = requests.get(FUND_GZ.format(code=code), headers=UA, timeout=15)
        if r.status_code != 200:
            return None
        payload = _parse_jsonp(r.text)
        if not payload or payload.get("fundcode") in (None, ""):
            return None

        def f(x):
            try:
                return float(str(x).replace("%", "").strip())
            except Exception:
                return None

        return {
            "code": payload.get("fundcode", code),
            "name": payload.get("name"),
            "gz": f(payload.get("gsz")),
            "gz_change_pct": f(payload.get("gszzl")),
            "nav": f(payload.get("dwjz")),
            "date": payload.get("jzrq"),
            "gz_time": payload.get("gztime"),
        }
    except Exception:
        return None


@st.cache_data(ttl=6 * 3600, show_spinner=False)
def get_fund_history(code: str, pages: int = 2, per: int = 200) -> List[Tuple[str, float]]:
    out: List[Tuple[str, float]] = []
    code = code.strip()
    for page in range(1, pages + 1):
        url = FUND_LSJZ.format(code=code, page=page, per=per)
        r = requests.get(url, headers=UA, timeout=20)
        if r.status_code != 200:
            continue
        try:
            tables = pd.read_html(r.text)
        except Exception:
            continue
        if not tables:
            continue
        df = tables[0]
        if "净值日期" not in df.columns:
            continue
        for _, row in df.iterrows():
            dt = str(row.get("净值日期"))
            nav = row.get("单位净值")
            try:
                nav_f = float(nav)
            except Exception:
                continue
            out.append((dt, nav_f))
        time.sleep(0.2)

    m = {}
    for dt, nav in out:
        m[dt] = nav
    items = sorted(m.items(), key=lambda x: x[0])
    return items


def calc_risk_from_nav_series(series: List[Tuple[str, float]]):
    import statistics
    navs = [v for _, v in series if isinstance(v, (int, float))]
    if len(navs) < 30:
        return 50, "观望", {"reason": "insufficient_history"}

    rets = []
    for i in range(1, len(navs)):
        if navs[i - 1] <= 0:
            continue
        rets.append(navs[i] / navs[i - 1] - 1.0)

    if len(rets) < 20:
        return 50, "观望", {"reason": "insufficient_returns"}

    vol = statistics.pstdev(rets)
    peak = navs[0]
    max_dd = 0.0
    for v in navs:
        if v > peak:
            peak = v
        dd = (peak - v) / peak if peak > 0 else 0
        if dd > max_dd:
            max_dd = dd

    score = int(min(100, vol * 4000 + max_dd * 200))
    if score >= 75:
        advice = "减仓"
    elif score <= 35:
        advice = "可加仓"
    else:
        advice = "观望"
    return score, advice, {"daily_vol": vol, "max_drawdown_pct": max_dd, "sample_days": len(rets)}


def wl_get() -> List[str]:
    conn = db()
    cur = conn.cursor()
    rows = cur.execute("SELECT code FROM watchlist ORDER BY code").fetchall()
    return [r[0] for r in rows]


def wl_add(code: str):
    conn = db()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO watchlist VALUES(?)", (code.strip(),))
    conn.commit()


def wl_del(code: str):
    conn = db()
    cur = conn.cursor()
    cur.execute("DELETE FROM watchlist WHERE code=?", (code.strip(),))
    conn.commit()


st.set_page_config(page_title="基金AI（个人版）", layout="wide")
st.title("基金AI（个人版）- 网页版 v0.3")
st.caption("全市场基金搜索（A/C筛选）｜盘中估值｜历史净值｜风险评分｜自选列表。仅供个人参考。")

with st.sidebar:
    st.header("导航")
    page = st.radio("选择页面", ["自选", "全基金搜索", "基金详情"], index=0)
    st.divider()
    st.subheader("数据")
    if st.button("刷新全基金清单（7天缓存）"):
        n = refresh_universe(force=True)
        st.success(f"已刷新基金清单：{n} 条")

with st.spinner("初始化基金清单..."):
    refresh_universe(force=False)

if page == "自选":
    st.subheader("⭐ 自选基金")
    cols = st.columns([2, 1])
    with cols[0]:
        add_code = st.text_input("添加基金代码", placeholder="例如：161039")
    with cols[1]:
        if st.button("加入自选"):
            if add_code.strip():
                wl_add(add_code)
                st.success(f"已加入：{add_code.strip()}")
                st.rerun()

    codes = wl_get()
    if not codes:
        st.info("你的自选还空着。去「全基金搜索」找到基金后加入。")
    else:
        rows = []
        for c in codes:
            q = get_fund_gz(c) or {"code": c}
            hist = get_fund_history(c, pages=2, per=200)
            if hist:
                score, advice, metrics = calc_risk_from_nav_series(hist)
            else:
                score, advice, metrics = None, "N/A", {}
            rows.append({
                "代码": c,
                "名称": q.get("name"),
                "估算净值": q.get("gz"),
                "估算涨跌%": q.get("gz_change_pct"),
                "估值时间": q.get("gz_time"),
                "最新净值": q.get("nav"),
                "净值日期": q.get("date"),
                "风险": score,
                "建议": advice,
            })
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True, hide_index=True)

        del_code = st.selectbox("删除自选", options=[""] + codes)
        if st.button("删除所选") and del_code:
            wl_del(del_code)
            st.success(f"已删除：{del_code}")
            st.rerun()

elif page == "全基金搜索":
    st.subheader("🔎 全市场基金搜索（覆盖支付宝大部分基金展示）")
    q = st.text_input("输入基金代码/名称/拼音", placeholder="例如：科技 / 161039 / zhongou")
    share = st.selectbox("份额过滤", options=["A", "C", "all"], index=0)
    limit = st.slider("返回条数", min_value=20, max_value=200, value=50, step=10)

    if st.button("搜索"):
        items = search_universe(q=q, share_class=share, limit=limit)
        st.write(f"结果：{len(items)} 条")
        if items:
            df = pd.DataFrame(items)
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption("提示：去「基金详情」页输入代码查看估值/风险；或在下面直接加入自选。")

            add = st.text_input("把代码加入自选", placeholder="从结果里复制代码，例如：161039")
            if st.button("加入自选（从搜索页）") and add.strip():
                wl_add(add.strip())
                st.success(f"已加入：{add.strip()}")
        else:
            st.warning("没有找到。换个关键字试试。")

elif page == "基金详情":
    st.subheader("📌 基金详情（估值 + 风险 + 净值曲线）")
    code = st.text_input("基金代码", placeholder="例如：161039")
    colA, colB = st.columns([1, 1])

    if st.button("加载"):
        if not code.strip():
            st.warning("请输入基金代码")
        else:
            code = code.strip()
            q = get_fund_gz(code)
            if not q:
                st.error("未能获取估值数据（可能该基金不支持估值接口或暂时不可用）。")
            else:
                st.markdown(f"### {q.get('name','')} ({code})")
                colA.metric("估算净值", q.get("gz"), q.get("gz_change_pct"))
                colB.metric("最新净值", q.get("nav"), None)
                st.write(f"估值时间：{q.get('gz_time')} | 净值日期：{q.get('date')}")

            hist = get_fund_history(code, pages=3, per=200)
            if not hist:
                st.warning("历史净值获取失败。")
            else:
                score, advice, metrics = calc_risk_from_nav_series(hist)
                st.info(
                    f"风险评分：{score} / 100   建议：{advice}   | 波动(日)：{metrics.get('daily_vol'):.4f}  回撤：{metrics.get('max_drawdown_pct'):.2%}"
                )

                df = pd.DataFrame(hist, columns=["日期", "单位净值"])
                df["日期"] = pd.to_datetime(df["日期"], errors="coerce")
                df = df.dropna().sort_values("日期")
                st.line_chart(df.set_index("日期")["单位净值"], height=260)

                st.caption("风险提示：基于历史波动与回撤的量化评分，仅用于个人风控参考。")
